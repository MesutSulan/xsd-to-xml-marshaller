
package com.xsdxto.xml;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OECDLegalAddressType_EnumType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="OECDLegalAddressType_EnumType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}token">
 *     &lt;enumeration value="OECD301"/>
 *     &lt;enumeration value="OECD302"/>
 *     &lt;enumeration value="OECD303"/>
 *     &lt;enumeration value="OECD304"/>
 *     &lt;enumeration value="OECD305"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "OECDLegalAddressType_EnumType", namespace = "urn:oecd:ties:stf:v4")
@XmlEnum
public enum OECDLegalAddressTypeEnumType {

    @XmlEnumValue("OECD301")
    OECD_301("OECD301"),
    @XmlEnumValue("OECD302")
    OECD_302("OECD302"),
    @XmlEnumValue("OECD303")
    OECD_303("OECD303"),
    @XmlEnumValue("OECD304")
    OECD_304("OECD304"),
    @XmlEnumValue("OECD305")
    OECD_305("OECD305");
    private final String value;

    OECDLegalAddressTypeEnumType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static OECDLegalAddressTypeEnumType fromValue(String v) {
        for (OECDLegalAddressTypeEnumType c: OECDLegalAddressTypeEnumType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
