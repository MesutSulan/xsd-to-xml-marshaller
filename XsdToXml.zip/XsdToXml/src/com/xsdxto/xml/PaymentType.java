
package com.xsdxto.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * Type that contains details about payment type
 * 
 * <p>Java class for Payment_Type complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Payment_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Type" type="{urn:oecd:ties:fatca:v2}FatcaPaymentType_EnumType"/>
 *         &lt;element name="PaymentTypeDesc" type="{urn:oecd:ties:stffatcatypes:v2}StringMax4000_Type" minOccurs="0"/>
 *         &lt;element name="PaymentAmnt" type="{urn:oecd:ties:stffatcatypes:v2}MonAmnt_Type"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Payment_Type", namespace = "urn:oecd:ties:fatca:v2", propOrder = {
    "type",
    "paymentTypeDesc",
    "paymentAmnt"
})
public class PaymentType {

    @XmlElement(name = "Type", namespace = "urn:oecd:ties:fatca:v2", required = true)
    @XmlSchemaType(name = "string")
    protected FatcaPaymentTypeEnumType type;
    @XmlElement(name = "PaymentTypeDesc", namespace = "urn:oecd:ties:fatca:v2")
    protected String paymentTypeDesc;
    @XmlElement(name = "PaymentAmnt", namespace = "urn:oecd:ties:fatca:v2", required = true)
    protected MonAmntType paymentAmnt;

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link FatcaPaymentTypeEnumType }
     *     
     */
    public FatcaPaymentTypeEnumType getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link FatcaPaymentTypeEnumType }
     *     
     */
    public void setType(FatcaPaymentTypeEnumType value) {
        this.type = value;
    }

    /**
     * Gets the value of the paymentTypeDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaymentTypeDesc() {
        return paymentTypeDesc;
    }

    /**
     * Sets the value of the paymentTypeDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaymentTypeDesc(String value) {
        this.paymentTypeDesc = value;
    }

    /**
     * Gets the value of the paymentAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link MonAmntType }
     *     
     */
    public MonAmntType getPaymentAmnt() {
        return paymentAmnt;
    }

    /**
     * Sets the value of the paymentAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link MonAmntType }
     *     
     */
    public void setPaymentAmnt(MonAmntType value) {
        this.paymentAmnt = value;
    }

}
