package com.xsdxto.xml;

import java.util.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="MessageSpec" type="{urn:oecd:ties:stffatcatypes:v2}MessageSpec_Type"/>
 *         &lt;element name="FATCA" type="{urn:oecd:ties:fatca:v2}Fatca_Type" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *       &lt;attribute name="version" type="{urn:oecd:ties:stffatcatypes:v2}StringMax10_Type" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "messageSpec",
    "fatca",
})
@XmlRootElement(name = "FATCA_OECD", namespace = "urn:oecd:ties:fatca:v2")
public class FATCAOECD {

    @XmlElement(name = "MessageSpec", namespace = "urn:oecd:ties:fatca:v2", required = true)
    protected MessageSpecType messageSpec;
    @XmlElement(name = "FATCA", namespace = "urn:oecd:ties:fatca:v2", required = true)
    protected List<FatcaType> fatca;
    @XmlAttribute(name = "version")
    protected String version;

    /**
     * Gets the value of the messageSpec property.
     * 
     * @return
     *     possible object is
     *     {@link MessageSpecType }
     *     
     */
    public MessageSpecType getMessageSpec() {
        return messageSpec;
    }

    /**
     * Sets the value of the messageSpec property.
     * 
     * @param value
     *     allowed object is
     *     {@link MessageSpecType }
     *     
     */
    public void setMessageSpec(MessageSpecType value) {
        this.messageSpec = value;
    }

    /**
     * Gets the value of the fatca property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the fatca property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFATCA().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FatcaType }
     * 
     * 
     */
    public List<FatcaType> getFATCA() {
        if (fatca == null) {
            fatca = new ArrayList<FatcaType>();
        }
        return this.fatca;
    }

    /**
     * Gets the value of the version property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVersion() {
        return version;
    }

    /**
     * Sets the value of the version property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVersion(String value) {
        this.version = value;
    }



}
