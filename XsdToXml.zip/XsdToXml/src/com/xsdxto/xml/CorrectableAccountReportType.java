
package com.xsdxto.xml;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Type that contains details about account report
 * 
 * <p>Java class for CorrectableAccountReport_Type complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CorrectableAccountReport_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DocSpec" type="{urn:oecd:ties:fatca:v2}DocSpec_Type"/>
 *         &lt;element name="AccountNumber" type="{urn:oecd:ties:fatca:v2}FIAccountNumber_Type"/>
 *         &lt;element name="AccountClosed" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="AccountHolder" type="{urn:oecd:ties:fatca:v2}AccountHolder_Type"/>
 *         &lt;element name="SubstantialOwner" type="{urn:oecd:ties:fatca:v2}SubstantialOwner_Type" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="AccountBalance" type="{urn:oecd:ties:stffatcatypes:v2}MonAmnt_Type"/>
 *         &lt;element name="Payment" type="{urn:oecd:ties:fatca:v2}Payment_Type" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="CARRef" type="{urn:oecd:ties:fatca:v2}CARRef_Type" minOccurs="0"/>
 *         &lt;element name="AdditionalData" type="{urn:oecd:ties:fatca:v2}AdditionalData_Type" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CorrectableAccountReport_Type", namespace = "urn:oecd:ties:fatca:v2", propOrder = {
    "docSpec",
    "accountNumber",
    "accountClosed",
    "accountHolder",
    "substantialOwner",
    "accountBalance",
    "payment",
    "carRef",
    "additionalData"
})
public class CorrectableAccountReportType {

    @XmlElement(name = "DocSpec", namespace = "urn:oecd:ties:fatca:v2", required = true)
    protected DocSpecType docSpec;
    @XmlElement(name = "AccountNumber", namespace = "urn:oecd:ties:fatca:v2", required = true)
    protected FIAccountNumberType accountNumber;
    @XmlElement(name = "AccountClosed", namespace = "urn:oecd:ties:fatca:v2")
    protected Boolean accountClosed;
    @XmlElement(name = "AccountHolder", namespace = "urn:oecd:ties:fatca:v2", required = true)
    protected AccountHolderType accountHolder;
    @XmlElement(name = "SubstantialOwner", namespace = "urn:oecd:ties:fatca:v2")
    protected List<SubstantialOwnerType> substantialOwner;
    @XmlElement(name = "AccountBalance", namespace = "urn:oecd:ties:fatca:v2", required = true)
    protected MonAmntType accountBalance;
    @XmlElement(name = "Payment", namespace = "urn:oecd:ties:fatca:v2")
    protected List<PaymentType> payment;
    @XmlElement(name = "CARRef", namespace = "urn:oecd:ties:fatca:v2")
    protected CARRefType carRef;
    @XmlElement(name = "AdditionalData", namespace = "urn:oecd:ties:fatca:v2")
    protected AdditionalDataType additionalData;

    /**
     * Gets the value of the docSpec property.
     * 
     * @return
     *     possible object is
     *     {@link DocSpecType }
     *     
     */
    public DocSpecType getDocSpec() {
        return docSpec;
    }

    /**
     * Sets the value of the docSpec property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocSpecType }
     *     
     */
    public void setDocSpec(DocSpecType value) {
        this.docSpec = value;
    }

    /**
     * Gets the value of the accountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link FIAccountNumberType }
     *     
     */
    public FIAccountNumberType getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link FIAccountNumberType }
     *     
     */
    public void setAccountNumber(FIAccountNumberType value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the accountClosed property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAccountClosed() {
        return accountClosed;
    }

    /**
     * Sets the value of the accountClosed property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAccountClosed(Boolean value) {
        this.accountClosed = value;
    }

    /**
     * Gets the value of the accountHolder property.
     * 
     * @return
     *     possible object is
     *     {@link AccountHolderType }
     *     
     */
    public AccountHolderType getAccountHolder() {
        return accountHolder;
    }

    /**
     * Sets the value of the accountHolder property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccountHolderType }
     *     
     */
    public void setAccountHolder(AccountHolderType value) {
        this.accountHolder = value;
    }

    /**
     * Gets the value of the substantialOwner property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the substantialOwner property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSubstantialOwner().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SubstantialOwnerType }
     * 
     * 
     */
    public List<SubstantialOwnerType> getSubstantialOwner() {
        if (substantialOwner == null) {
            substantialOwner = new ArrayList<SubstantialOwnerType>();
        }
        return this.substantialOwner;
    }

    /**
     * Gets the value of the accountBalance property.
     * 
     * @return
     *     possible object is
     *     {@link MonAmntType }
     *     
     */
    public MonAmntType getAccountBalance() {
        return accountBalance;
    }

    /**
     * Sets the value of the accountBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link MonAmntType }
     *     
     */
    public void setAccountBalance(MonAmntType value) {
        this.accountBalance = value;
    }

    /**
     * Gets the value of the payment property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the payment property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPayment().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PaymentType }
     * 
     * 
     */
    public List<PaymentType> getPayment() {
        if (payment == null) {
            payment = new ArrayList<PaymentType>();
        }
        return this.payment;
    }

    /**
     * Gets the value of the carRef property.
     * 
     * @return
     *     possible object is
     *     {@link CARRefType }
     *     
     */
    public CARRefType getCARRef() {
        return carRef;
    }

    /**
     * Sets the value of the carRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link CARRefType }
     *     
     */
    public void setCARRef(CARRefType value) {
        this.carRef = value;
    }

    /**
     * Gets the value of the additionalData property.
     * 
     * @return
     *     possible object is
     *     {@link AdditionalDataType }
     *     
     */
    public AdditionalDataType getAdditionalData() {
        return additionalData;
    }

    /**
     * Sets the value of the additionalData property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdditionalDataType }
     *     
     */
    public void setAdditionalData(AdditionalDataType value) {
        this.additionalData = value;
    }

}
