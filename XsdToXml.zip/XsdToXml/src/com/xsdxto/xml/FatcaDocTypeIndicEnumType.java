
package com.xsdxto.xml;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FatcaDocTypeIndic_EnumType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="FatcaDocTypeIndic_EnumType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="FATCA1"/>
 *     &lt;enumeration value="FATCA2"/>
 *     &lt;enumeration value="FATCA3"/>
 *     &lt;enumeration value="FATCA4"/>
 *     &lt;enumeration value="FATCA11"/>
 *     &lt;enumeration value="FATCA12"/>
 *     &lt;enumeration value="FATCA13"/>
 *     &lt;enumeration value="FATCA14"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "FatcaDocTypeIndic_EnumType", namespace = "urn:oecd:ties:fatca:v2")
@XmlEnum
public enum FatcaDocTypeIndicEnumType {


    /**
     * New Data
     * 
     */
    @XmlEnumValue("FATCA1")
    FATCA_1("FATCA1"),

    /**
     * Corrected Data
     * 
     */
    @XmlEnumValue("FATCA2")
    FATCA_2("FATCA2"),

    /**
     * Void Data
     * 
     */
    @XmlEnumValue("FATCA3")
    FATCA_3("FATCA3"),

    /**
     * Amended Data
     * 
     */
    @XmlEnumValue("FATCA4")
    FATCA_4("FATCA4"),

    /**
     * New Test Data
     * 
     */
    @XmlEnumValue("FATCA11")
    FATCA_11("FATCA11"),

    /**
     * Corrected Test Data
     * 
     */
    @XmlEnumValue("FATCA12")
    FATCA_12("FATCA12"),

    /**
     * Void Test Data
     * 
     */
    @XmlEnumValue("FATCA13")
    FATCA_13("FATCA13"),

    /**
     * Amended Test Data
     * 
     */
    @XmlEnumValue("FATCA14")
    FATCA_14("FATCA14");
    private final String value;

    FatcaDocTypeIndicEnumType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static FatcaDocTypeIndicEnumType fromValue(String v) {
        for (FatcaDocTypeIndicEnumType c: FatcaDocTypeIndicEnumType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
