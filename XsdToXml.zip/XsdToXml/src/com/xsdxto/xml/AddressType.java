
package com.xsdxto.xml;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlElementRefs;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * The user may enter data about the party address either as (1) AddressFree (2) AddressFix or (3) a combination of both. If the user of a party either as one long field or to spread the data over up to eight elements or even to use both formats. If the user chooses the option to enter the data required in separate elements, the container element for this will be 'AddressFix'. If the user chooses the option to enter the data required in a less structured way in 'AddressFree' all available address details shall be presented as one string of bytes, blank or "/" (slash) or carriage return- line feed used as a delimiter between parts of the address. PLEASE NOTE that the address country code is outside both of these elements. Use AddressFix format to allow easy matching and use AddressFree if the sender cannot identify the different parts of the address. May use both formats, City element is required and and 'AddressFix' has to precede 'AddressFree'.
 * 
 * <p>Java class for Address_Type complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Address_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CountryCode" type="{urn:oecd:ties:isofatcatypes:v1}CountryCode_Type"/>
 *         &lt;choice>
 *           &lt;element name="AddressFree" type="{urn:oecd:ties:stffatcatypes:v2}StringMax4000_Type"/>
 *           &lt;sequence>
 *             &lt;element name="AddressFix" type="{urn:oecd:ties:stffatcatypes:v2}AddressFix_Type"/>
 *             &lt;element name="AddressFree" type="{urn:oecd:ties:stffatcatypes:v2}StringMax4000_Type" minOccurs="0"/>
 *           &lt;/sequence>
 *         &lt;/choice>
 *       &lt;/sequence>
 *       &lt;attribute name="legalAddressType" type="{urn:oecd:ties:stf:v4}OECDLegalAddressType_EnumType" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Address_Type", namespace = "urn:oecd:ties:stffatcatypes:v2", propOrder = {
    "content",
    "CountryCodeType",
    "AddressFixType"
})
public class AddressType {

    @XmlElementRefs({
        @XmlElementRef(name = "AddressFix", namespace = "urn:oecd:ties:stffatcatypes:v2", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "AddressFree", namespace = "urn:oecd:ties:stffatcatypes:v2", type = JAXBElement.class, required = false),
        @XmlElementRef(name = "CountryCode", namespace = "urn:oecd:ties:stffatcatypes:v2", type = JAXBElement.class, required = false)
    })
    protected List<JAXBElement<?>> content;
    @XmlAttribute(name = "legalAddressType")
    protected OECDLegalAddressTypeEnumType legalAddressType;

    HashSet<CountryCodeType> CountryCodeType;
    HashSet<AddressFixType> AddressFixType;


    public void setCountryCodeTypes(HashSet<CountryCodeType> countryCodeTypes) {
        this.CountryCodeType = countryCodeTypes;
    }

    public void setAddressFixType(HashSet<com.xsdxto.xml.AddressFixType> addressFixType) {
        AddressFixType = addressFixType;
    }

    /**
     * Gets the rest of the content model. 
     * 
     * <p>
     * You are getting this "catch-all" property because of the following reason: 
     * The field name "AddressFree" is used by two different parts of a schema. See: 
     * line 132 of file:/C:/Users/LENOVO/IdeaProjects/XsdToXml/stffatcatypes_v2.0.xsd
     * line 121 of file:/C:/Users/LENOVO/IdeaProjects/XsdToXml/stffatcatypes_v2.0.xsd
     * <p>
     * To get rid of this property, apply a property customization to one 
     * of both of the following declarations to change their names: 
     * Gets the value of the content property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the content property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContent().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link JAXBElement }{@code <}{@link AddressFixType }{@code >}
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     * {@link JAXBElement }{@code <}{@link CountryCodeType }{@code >}
     * 
     * 
     */
    public List<JAXBElement<?>> getContent() {
        if (content == null) {
            content = new ArrayList<JAXBElement<?>>();
        }
        return this.content;
    }

    /**
     * Gets the value of the legalAddressType property.
     * 
     * @return
     *     possible object is
     *     {@link OECDLegalAddressTypeEnumType }
     *     
     */
    public OECDLegalAddressTypeEnumType getLegalAddressType() {
        return legalAddressType;
    }

    /**
     * Sets the value of the legalAddressType property.
     * 
     * @param value
     *     allowed object is
     *     {@link OECDLegalAddressTypeEnumType }
     *     
     */
    public void setLegalAddressType(OECDLegalAddressTypeEnumType value) {
        this.legalAddressType = value;
    }
}
