package com.xsdxto.xml;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapters;


/**
 * Type that contains details about FATCA report
 * 
 * <p>Java class for Fatca_Type complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Fatca_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ReportingFI" type="{urn:oecd:ties:fatca:v2}CorrectableReportOrganisation_Type"/>
 *         &lt;element name="ReportingGroup" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Sponsor" type="{urn:oecd:ties:fatca:v2}CorrectableReportOrganisation_Type" minOccurs="0"/>
 *                   &lt;element name="Intermediary" type="{urn:oecd:ties:fatca:v2}CorrectableReportOrganisation_Type" minOccurs="0"/>
 *                   &lt;choice>
 *                     &lt;element name="NilReport" type="{urn:oecd:ties:fatca:v2}CorrectableNilReport_Type"/>
 *                     &lt;sequence>
 *                       &lt;element name="AccountReport" type="{urn:oecd:ties:fatca:v2}CorrectableAccountReport_Type" maxOccurs="unbounded" minOccurs="0"/>
 *                       &lt;element name="PoolReport" type="{urn:oecd:ties:fatca:v2}CorrectablePoolReport_Type" maxOccurs="unbounded" minOccurs="0"/>
 *                     &lt;/sequence>
 *                   &lt;/choice>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Fatca_Type", namespace = "urn:oecd:ties:fatca:v2", propOrder = {
    "reportingFI",
    "reportingGroup",
    "AddressType"
})
public class FatcaType {

    @XmlElement(name = "ReportingFI", namespace = "urn:oecd:ties:fatca:v2", required = true)
    protected CorrectableReportOrganisationType reportingFI;
    @XmlElement(name = "ReportingGroup", namespace = "urn:oecd:ties:fatca:v2", required = true)
    protected List<FatcaType.ReportingGroup> reportingGroup;

    HashSet<AddressType> AddressType;

    public HashSet<com.xsdxto.xml.AddressType> getAddressType() {
        return AddressType;
    }

    public void setAddressType(HashSet<com.xsdxto.xml.AddressType> addressType) {
        AddressType = addressType;
    }

    /**
     * Gets the value of the reportingFI property.
     * 
     * @return
     *     possible object is
     *     {@link CorrectableReportOrganisationType }
     *     
     */
    public CorrectableReportOrganisationType getReportingFI() {
        return reportingFI;
    }

    /**
     * Sets the value of the reportingFI property.
     * 
     * @param value
     *     allowed object is
     *     {@link CorrectableReportOrganisationType }
     *     
     */
    public void setReportingFI(CorrectableReportOrganisationType value) {
        this.reportingFI = value;
    }

    /**
     * Gets the value of the reportingGroup property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the reportingGroup property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReportingGroup().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FatcaType.ReportingGroup }
     * 
     * 
     */
    public List<FatcaType.ReportingGroup> getReportingGroup() {
        if (reportingGroup == null) {
            reportingGroup = new ArrayList<FatcaType.ReportingGroup>();
        }
        return this.reportingGroup;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Sponsor" type="{urn:oecd:ties:fatca:v2}CorrectableReportOrganisation_Type" minOccurs="0"/>
     *         &lt;element name="Intermediary" type="{urn:oecd:ties:fatca:v2}CorrectableReportOrganisation_Type" minOccurs="0"/>
     *         &lt;choice>
     *           &lt;element name="NilReport" type="{urn:oecd:ties:fatca:v2}CorrectableNilReport_Type"/>
     *           &lt;sequence>
     *             &lt;element name="AccountReport" type="{urn:oecd:ties:fatca:v2}CorrectableAccountReport_Type" maxOccurs="unbounded" minOccurs="0"/>
     *             &lt;element name="PoolReport" type="{urn:oecd:ties:fatca:v2}CorrectablePoolReport_Type" maxOccurs="unbounded" minOccurs="0"/>
     *           &lt;/sequence>
     *         &lt;/choice>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "sponsor",
        "intermediary",
        "nilReport",
        "accountReport",
        "poolReport"
    })
    public static class ReportingGroup {

        @XmlElement(name = "Sponsor", namespace = "urn:oecd:ties:fatca:v2")
        protected CorrectableReportOrganisationType sponsor;
        @XmlElement(name = "Intermediary", namespace = "urn:oecd:ties:fatca:v2")
        protected CorrectableReportOrganisationType intermediary;
        @XmlElement(name = "NilReport", namespace = "urn:oecd:ties:fatca:v2")
        protected CorrectableNilReportType nilReport;
        @XmlElement(name = "AccountReport", namespace = "urn:oecd:ties:fatca:v2")
        protected List<CorrectableAccountReportType> accountReport;
        @XmlElement(name = "PoolReport", namespace = "urn:oecd:ties:fatca:v2")
        protected List<CorrectablePoolReportType> poolReport;

        /**
         * Gets the value of the sponsor property.
         * 
         * @return
         *     possible object is
         *     {@link CorrectableReportOrganisationType }
         *     
         */
        public CorrectableReportOrganisationType getSponsor() {
            return sponsor;
        }

        /**
         * Sets the value of the sponsor property.
         * 
         * @param value
         *     allowed object is
         *     {@link CorrectableReportOrganisationType }
         *     
         */
        public void setSponsor(CorrectableReportOrganisationType value) {
            this.sponsor = value;
        }

        /**
         * Gets the value of the intermediary property.
         * 
         * @return
         *     possible object is
         *     {@link CorrectableReportOrganisationType }
         *     
         */
        public CorrectableReportOrganisationType getIntermediary() {
            return intermediary;
        }

        /**
         * Sets the value of the intermediary property.
         * 
         * @param value
         *     allowed object is
         *     {@link CorrectableReportOrganisationType }
         *     
         */
        public void setIntermediary(CorrectableReportOrganisationType value) {
            this.intermediary = value;
        }

        /**
         * Gets the value of the nilReport property.
         * 
         * @return
         *     possible object is
         *     {@link CorrectableNilReportType }
         *     
         */
        public CorrectableNilReportType getNilReport() {
            return nilReport;
        }

        /**
         * Sets the value of the nilReport property.
         * 
         * @param value
         *     allowed object is
         *     {@link CorrectableNilReportType }
         *     
         */
        public void setNilReport(CorrectableNilReportType value) {
            this.nilReport = value;
        }

        /**
         * Gets the value of the accountReport property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the accountReport property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getAccountReport().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link CorrectableAccountReportType }
         * 
         * 
         */
        public List<CorrectableAccountReportType> getAccountReport() {
            if (accountReport == null) {
                accountReport = new ArrayList<CorrectableAccountReportType>();
            }
            return this.accountReport;
        }

        /**
         * Gets the value of the poolReport property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the poolReport property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getPoolReport().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link CorrectablePoolReportType }
         * 
         * 
         */
        public List<CorrectablePoolReportType> getPoolReport() {
            if (poolReport == null) {
                poolReport = new ArrayList<CorrectablePoolReportType>();
            }
            return this.poolReport;
        }

    }

}
