
package com.xsdxto.xml;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * 
 * This data type is to be used whenever monetary amounts are communicated. Such amounts are entered with 
 *  2-digit fractions of the main currency unit, e.g. 50500.00. The currency code is based on ISO 4217 and included in attribute currCode.
 * 
 * 
 * <p>Java class for MonAmnt_Type complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MonAmnt_Type">
 *   &lt;simpleContent>
 *     &lt;extension base="&lt;urn:oecd:ties:stffatcatypes:v2>TwoDigFract_Type">
 *       &lt;attribute name="currCode" use="required" type="{urn:oecd:ties:isofatcatypes:v1}currCode_Type" />
 *     &lt;/extension>
 *   &lt;/simpleContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MonAmnt_Type", namespace = "urn:oecd:ties:stffatcatypes:v2", propOrder = {
    "value"
})
public class MonAmntType {

    @XmlValue
    protected BigDecimal value;
    @XmlAttribute(name = "currCode", required = true)
    protected CurrCodeType currCode;

    /**
     * Data type for any kind of numeric data with two decimal fraction digits, especially monetary amounts
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setValue(BigDecimal value) {
        this.value = value;
    }

    /**
     * Gets the value of the currCode property.
     * 
     * @return
     *     possible object is
     *     {@link CurrCodeType }
     *     
     */
    public CurrCodeType getCurrCode() {
        return currCode;
    }

    /**
     * Sets the value of the currCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrCodeType }
     *     
     */
    public void setCurrCode(CurrCodeType value) {
        this.currCode = value;
    }

}
