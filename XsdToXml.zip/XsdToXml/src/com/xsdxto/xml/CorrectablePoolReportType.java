
package com.xsdxto.xml;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * Type that contains details about the pool report
 * 
 * <p>Java class for CorrectablePoolReport_Type complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CorrectablePoolReport_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DocSpec" type="{urn:oecd:ties:fatca:v2}DocSpec_Type"/>
 *         &lt;element name="AccountCount" type="{http://www.w3.org/2001/XMLSchema}positiveInteger"/>
 *         &lt;element name="AccountPoolReportType" type="{urn:oecd:ties:fatca:v2}FatcaAcctPoolReportType_EnumType"/>
 *         &lt;element name="PoolBalance" type="{urn:oecd:ties:stffatcatypes:v2}MonAmnt_Type"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CorrectablePoolReport_Type", namespace = "urn:oecd:ties:fatca:v2", propOrder = {
    "docSpec",
    "accountCount",
    "accountPoolReportType",
    "poolBalance"
})
public class CorrectablePoolReportType {

    @XmlElement(name = "DocSpec", namespace = "urn:oecd:ties:fatca:v2", required = true)
    protected DocSpecType docSpec;
    @XmlElement(name = "AccountCount", namespace = "urn:oecd:ties:fatca:v2", required = true)
    @XmlSchemaType(name = "positiveInteger")
    protected BigInteger accountCount;
    @XmlElement(name = "AccountPoolReportType", namespace = "urn:oecd:ties:fatca:v2", required = true)
    @XmlSchemaType(name = "string")
    protected FatcaAcctPoolReportTypeEnumType accountPoolReportType;
    @XmlElement(name = "PoolBalance", namespace = "urn:oecd:ties:fatca:v2", required = true)
    protected MonAmntType poolBalance;

    /**
     * Gets the value of the docSpec property.
     * 
     * @return
     *     possible object is
     *     {@link DocSpecType }
     *     
     */
    public DocSpecType getDocSpec() {
        return docSpec;
    }

    /**
     * Sets the value of the docSpec property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocSpecType }
     *     
     */
    public void setDocSpec(DocSpecType value) {
        this.docSpec = value;
    }

    /**
     * Gets the value of the accountCount property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getAccountCount() {
        return accountCount;
    }

    /**
     * Sets the value of the accountCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setAccountCount(BigInteger value) {
        this.accountCount = value;
    }

    /**
     * Gets the value of the accountPoolReportType property.
     * 
     * @return
     *     possible object is
     *     {@link FatcaAcctPoolReportTypeEnumType }
     *     
     */
    public FatcaAcctPoolReportTypeEnumType getAccountPoolReportType() {
        return accountPoolReportType;
    }

    /**
     * Sets the value of the accountPoolReportType property.
     * 
     * @param value
     *     allowed object is
     *     {@link FatcaAcctPoolReportTypeEnumType }
     *     
     */
    public void setAccountPoolReportType(FatcaAcctPoolReportTypeEnumType value) {
        this.accountPoolReportType = value;
    }

    /**
     * Gets the value of the poolBalance property.
     * 
     * @return
     *     possible object is
     *     {@link MonAmntType }
     *     
     */
    public MonAmntType getPoolBalance() {
        return poolBalance;
    }

    /**
     * Sets the value of the poolBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link MonAmntType }
     *     
     */
    public void setPoolBalance(MonAmntType value) {
        this.poolBalance = value;
    }

}
