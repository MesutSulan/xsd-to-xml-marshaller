
package com.xsdxto.xml;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MessageType_EnumType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="MessageType_EnumType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="FATCA"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "MessageType_EnumType", namespace = "urn:oecd:ties:stffatcatypes:v2")
@XmlEnum
public enum MessageTypeEnumType {

    FATCA;

    public String value() {
        return name();
    }

    public static MessageTypeEnumType fromValue(String v) {
        return valueOf(v);
    }

}
