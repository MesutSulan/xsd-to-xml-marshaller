
package com.xsdxto.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Type that contains details about Nil Report. Nil Report indicates that financial institution does not have accounts to report.
 * 
 * <p>Java class for CorrectableNilReport_Type complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CorrectableNilReport_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DocSpec" type="{urn:oecd:ties:fatca:v2}DocSpec_Type"/>
 *         &lt;element name="NoAccountToReport" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CorrectableNilReport_Type", namespace = "urn:oecd:ties:fatca:v2", propOrder = {
    "docSpec",
    "noAccountToReport"
})
public class CorrectableNilReportType {

    @XmlElement(name = "DocSpec", namespace = "urn:oecd:ties:fatca:v2", required = true)
    protected DocSpecType docSpec;
    @XmlElement(name = "NoAccountToReport", namespace = "urn:oecd:ties:fatca:v2", required = true)
    protected String noAccountToReport;

    /**
     * Gets the value of the docSpec property.
     * 
     * @return
     *     possible object is
     *     {@link DocSpecType }
     *     
     */
    public DocSpecType getDocSpec() {
        return docSpec;
    }

    /**
     * Sets the value of the docSpec property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocSpecType }
     *     
     */
    public void setDocSpec(DocSpecType value) {
        this.docSpec = value;
    }

    /**
     * Gets the value of the noAccountToReport property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNoAccountToReport() {
        return noAccountToReport;
    }

    /**
     * Sets the value of the noAccountToReport property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNoAccountToReport(String value) {
        this.noAccountToReport = value;
    }

}
