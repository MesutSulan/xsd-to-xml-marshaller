
package com.xsdxto.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Type that contains details for a substantial owner of an account
 * 
 * <p>Java class for SubstantialOwner_Type complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SubstantialOwner_Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;choice>
 *           &lt;element name="Individual" type="{urn:oecd:ties:stffatcatypes:v2}PersonParty_Type"/>
 *           &lt;element name="Organisation" type="{urn:oecd:ties:stffatcatypes:v2}OrganisationParty_Type"/>
 *         &lt;/choice>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SubstantialOwner_Type", namespace = "urn:oecd:ties:fatca:v2", propOrder = {
    "individual",
    "organisation"
})
public class SubstantialOwnerType {

    @XmlElement(name = "Individual", namespace = "urn:oecd:ties:fatca:v2")
    protected PersonPartyType individual;
    @XmlElement(name = "Organisation", namespace = "urn:oecd:ties:fatca:v2")
    protected OrganisationPartyType organisation;

    /**
     * Gets the value of the individual property.
     * 
     * @return
     *     possible object is
     *     {@link PersonPartyType }
     *     
     */
    public PersonPartyType getIndividual() {
        return individual;
    }

    /**
     * Sets the value of the individual property.
     * 
     * @param value
     *     allowed object is
     *     {@link PersonPartyType }
     *     
     */
    public void setIndividual(PersonPartyType value) {
        this.individual = value;
    }

    /**
     * Gets the value of the organisation property.
     * 
     * @return
     *     possible object is
     *     {@link OrganisationPartyType }
     *     
     */
    public OrganisationPartyType getOrganisation() {
        return organisation;
    }

    /**
     * Sets the value of the organisation property.
     * 
     * @param value
     *     allowed object is
     *     {@link OrganisationPartyType }
     *     
     */
    public void setOrganisation(OrganisationPartyType value) {
        this.organisation = value;
    }

}
