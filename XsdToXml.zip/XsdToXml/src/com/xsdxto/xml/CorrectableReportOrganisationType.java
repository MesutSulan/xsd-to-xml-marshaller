
package com.xsdxto.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * Type that contains details about entity that can act as a filer of report ( e.g. Sponsor, Reporting FI or Intermediary)
 * 
 * <p>Java class for CorrectableReportOrganisation_Type complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CorrectableReportOrganisation_Type">
 *   &lt;complexContent>
 *     &lt;extension base="{urn:oecd:ties:stffatcatypes:v2}OrganisationParty_Type">
 *       &lt;sequence>
 *         &lt;element name="FilerCategory" type="{urn:oecd:ties:fatca:v2}FatcaFilerCategory_EnumType" minOccurs="0"/>
 *         &lt;element name="DocSpec" type="{urn:oecd:ties:fatca:v2}DocSpec_Type"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CorrectableReportOrganisation_Type", namespace = "urn:oecd:ties:fatca:v2", propOrder = {
    "filerCategory",
    "docSpec"
})
public class CorrectableReportOrganisationType
    extends OrganisationPartyType
{

    @XmlElement(name = "FilerCategory", namespace = "urn:oecd:ties:fatca:v2")
    @XmlSchemaType(name = "string")
    protected FatcaFilerCategoryEnumType filerCategory;
    @XmlElement(name = "DocSpec", namespace = "urn:oecd:ties:fatca:v2", required = true)
    protected DocSpecType docSpec;

    /**
     * Gets the value of the filerCategory property.
     * 
     * @return
     *     possible object is
     *     {@link FatcaFilerCategoryEnumType }
     *     
     */
    public FatcaFilerCategoryEnumType getFilerCategory() {
        return filerCategory;
    }

    /**
     * Sets the value of the filerCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link FatcaFilerCategoryEnumType }
     *     
     */
    public void setFilerCategory(FatcaFilerCategoryEnumType value) {
        this.filerCategory = value;
    }

    /**
     * Gets the value of the docSpec property.
     * 
     * @return
     *     possible object is
     *     {@link DocSpecType }
     *     
     */
    public DocSpecType getDocSpec() {
        return docSpec;
    }

    /**
     * Sets the value of the docSpec property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocSpecType }
     *     
     */
    public void setDocSpec(DocSpecType value) {
        this.docSpec = value;
    }

}
