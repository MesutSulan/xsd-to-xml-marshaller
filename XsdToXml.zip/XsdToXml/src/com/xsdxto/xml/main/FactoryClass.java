package com.xsdxto.xml.main;

import com.xsdxto.xml.*;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.File;
import java.math.BigDecimal;
import java.util.HashSet;

public class FactoryClass {
    public FactoryClass() throws JAXBException {
        FATCAOECD veri = new FATCAOECD();
    FatcaType t = new FatcaType();
    CorrectableReportOrganisationType ot = new CorrectableReportOrganisationType();
    DocSpecType ds = new DocSpecType();
             ds.setCorrDocRefId("deneme");
             ds.setCorrMessageRefId("message deneme");
             ds.setDocRefId("doc ref id deneme");
             ds.setDocTypeIndic(FatcaDocTypeIndicEnumType.FATCA_1);
             ot.setDocSpec(ds);
             ot.setFilerCategory(FatcaFilerCategoryEnumType.FATCA_601);
             t.setReportingFI(ot);

    MessageSpecType mst = new MessageSpecType();

             mst.setReceivingCountry(CountryCodeType.TR);
             mst.setMessageRefId("message ref ID");
             mst.setSendingCompanyIN("İş Yatırım");

    FatcaType.ReportingGroup rg = new FatcaType.ReportingGroup();
    CorrectableAccountReportType cart = new CorrectableAccountReportType();
    MonAmntType mat = new MonAmntType();
             mat.setCurrCode(CurrCodeType.TRY);
             mat.setValue(new BigDecimal(5000));
             cart.setAccountBalance(mat);
             cart.setAccountClosed(false);

    FIAccountNumberType fan = new FIAccountNumberType();
             fan.setAcctNumberType(AcctNumberTypeEnumType.OECD_601);
             fan.setValue("546545456");
             cart.setAccountNumber(fan);

    PaymentType pt = new PaymentType();
             pt.setPaymentAmnt(mat);
             pt.setPaymentTypeDesc("payment desc");
             pt.setType(FatcaPaymentTypeEnumType.FATCA_503);
             cart.getPayment().add(pt);

    AccountHolderType ac = new AccountHolderType();
                ac.setAcctHolderType(FatcaAcctHolderTypeEnumType.FATCA_101);
                cart.setAccountHolder(ac);

    CARRefType ct = new  CARRefType();
                ct.setPoolReportDocRefId("Report Document");
                ct.setPoolReportReportingFIGIIN("Pool Reporting");
                ct.setPoolReportMessageRefId("Pool Report Message");
                cart.setCARRef(ct);

                // stffatcatypes_v2.0.xsd start
        HashSet<AddressType> atft = new HashSet<>();

        AddressType at = new  AddressType();
        at.setLegalAddressType(OECDLegalAddressTypeEnumType.OECD_301);
        atft.add(at);
        t.setAddressType(atft);

        HashSet<CountryCodeType> countryCodeTypes = new HashSet<>();
        countryCodeTypes.add(CountryCodeType.CA);
        at.setCountryCodeTypes(countryCodeTypes);

        HashSet<AddressFixType> aft = new HashSet<>();
    AddressFixType af = new AddressFixType();
                af.setCity("Mexico");
//                af.setPOB("Pob");
//                af.setBuildingIdentifier("Identifier");
                af.setStreet("Aşağı mahalle");
//                af.setDistrictName("Bilmiyorum");
//                af.setCountrySubentity("Antalya");
//                af.setFloorIdentifier("Flor Identifier");
                af.setPostCode("070400");
//                af.setSuiteIdentifier("Suite Identifier");
                //t.setAddressfixtype(addressFixTypes);
                aft.add(af);
                at.setAddressFixType(aft);






    MonAmntType mt = new MonAmntType();
                mt.setValue(new BigDecimal(6000));
                mt.setCurrCode(CurrCodeType.TRY); //valueOf("TRY")

    NameOrganisationType not = new NameOrganisationType();
                not.setValue("Name Organization");
                not.setNameType(OECDNameTypeEnumType.OECD_201);

    NamePersonType npt = new NamePersonType();
                //npt.setFirstName(npt.getFirstName());
                npt.setNameType(OECDNameTypeEnumType.OECD_203);
                //npt.setLastName(npt.getLastName());

    TINType tny = new TINType();
                tny.setValue("TINType");
                tny.setIssuedBy(CountryCodeType.TR);

    OrganisationPartyType opt = new OrganisationPartyType();
                opt.getTIN().add(tny);

        PersonPartyType.BirthInfo pptbt = new PersonPartyType.BirthInfo();
        pptbt.setCity("Istanbul");

    PersonPartyType ppt = new PersonPartyType();
                ppt.setBirthInfo(pptbt);

    MessageSpecType msst = new MessageSpecType();
                msst.setMessageRefId("REFID");
                msst.setTransmittingCountry(CountryCodeType.TR);
                msst.setReceivingCountry(CountryCodeType.AF);
                msst.setMessageType(MessageTypeEnumType.FATCA);

                // stffatcatypes_v2.0.xsd finish



             rg.getAccountReport().add(cart);

             t.getReportingGroup().add(rg);

             veri.setMessageSpec(mst);
             veri.getFATCA().add(t);

        JAXBContext jc = JAXBContext.newInstance(FATCAOECD.class);
        Marshaller marshaller = jc.createMarshaller();
        File f = new File("deneme.xml");
                    marshaller.marshal(veri, f);
    }



}
