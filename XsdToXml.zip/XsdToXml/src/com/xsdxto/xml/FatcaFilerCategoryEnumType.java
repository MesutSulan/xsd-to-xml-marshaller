
package com.xsdxto.xml;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FatcaFilerCategory_EnumType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="FatcaFilerCategory_EnumType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="FATCA601"/>
 *     &lt;enumeration value="FATCA602"/>
 *     &lt;enumeration value="FATCA603"/>
 *     &lt;enumeration value="FATCA604"/>
 *     &lt;enumeration value="FATCA605"/>
 *     &lt;enumeration value="FATCA606"/>
 *     &lt;enumeration value="FATCA607"/>
 *     &lt;enumeration value="FATCA608"/>
 *     &lt;enumeration value="FATCA609"/>
 *     &lt;enumeration value="FATCA610"/>
 *     &lt;enumeration value="FATCA611"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "FatcaFilerCategory_EnumType", namespace = "urn:oecd:ties:fatca:v2")
@XmlEnum
public enum FatcaFilerCategoryEnumType {


    /**
     * PFFI (other than a Reporting Model 2 FFI and including a U.S. branch of a PFFI not treated as a U.S. person)
     * 
     */
    @XmlEnumValue("FATCA601")
    FATCA_601("FATCA601"),

    /**
     * RDC FFI
     * 
     */
    @XmlEnumValue("FATCA602")
    FATCA_602("FATCA602"),

    /**
     * Limited Branch or Limited FFI
     * 
     */
    @XmlEnumValue("FATCA603")
    FATCA_603("FATCA603"),

    /**
     * Reporting Model 2 FFI
     * 
     */
    @XmlEnumValue("FATCA604")
    FATCA_604("FATCA604"),

    /**
     * QI, WP, or WT
     * 
     */
    @XmlEnumValue("FATCA605")
    FATCA_605("FATCA605"),

    /**
     * Direct Reporting NFFE
     * 
     */
    @XmlEnumValue("FATCA606")
    FATCA_606("FATCA606"),

    /**
     * Sponsoring Entity of a Sponsored FFI
     * 
     */
    @XmlEnumValue("FATCA607")
    FATCA_607("FATCA607"),

    /**
     * Sponsoring Entity of a Sponsored Direct Reporting NFFE
     * 
     */
    @XmlEnumValue("FATCA608")
    FATCA_608("FATCA608"),

    /**
     * Trustee of a Trustee-Documented Trust
     * 
     */
    @XmlEnumValue("FATCA609")
    FATCA_609("FATCA609"),

    /**
     * Withholding Agent (including a U.S. branch of a PFFI, Reporting Model 1 FFI, Reporting Model 2 FFI, or RDC FFI treated as a U.S. person and a U.S. branch of a Reporting Model 1 FFI (including any other RDC FFI) or Limited FFI that is not treated as a U.S. person)
     * 
     */
    @XmlEnumValue("FATCA610")
    FATCA_610("FATCA610"),

    /**
     * Territory Financial Institution treated as a U.S. person
     * 
     */
    @XmlEnumValue("FATCA611")
    FATCA_611("FATCA611");
    private final String value;

    FatcaFilerCategoryEnumType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static FatcaFilerCategoryEnumType fromValue(String v) {
        for (FatcaFilerCategoryEnumType c: FatcaFilerCategoryEnumType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
