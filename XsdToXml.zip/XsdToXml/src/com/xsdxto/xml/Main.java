package com.xsdxto.xml;

import com.xsdxto.xml.main.FactoryClass;

import javax.xml.bind.JAXBException;

public class Main {
    public static void main(String[] args) throws JAXBException {
        new FactoryClass();
    }
}
